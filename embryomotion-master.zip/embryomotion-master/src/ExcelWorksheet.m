classdef ExcelWorksheet < handle
    
    properties (SetAccess = private)
        workbook               ExcelWorkbook
    end
    
    properties (Access = private)
        wsRef
    end
    
    properties (Dependent)
        name
    end
    
    methods (Access = {?ExcelWorkbook})
        function self = ExcelWorksheet(workbook, wsRef)
            self.workbook = workbook;
            self.wsRef = wsRef;
        end
    end
    
    methods
        function name = get.name(self)
            name = self.wsRef.Name;
        end
        
        function set.name(self, newValue)
            self.wsRef.Name = newValue;
        end
        
        function writeValues(self, values, row, column)
            [nr, nc] = size(values);
            c1 = self.getCell(row, column);
            c2 = self.getCell(row+nr-1, column+nc-1);
            range = self.getCellRange(c1, c2);
            if ~iscell(values)
                values = num2cell(values);
            end
            range.Value = values;
        end
        
        function writePlotImage(self, axes, row, column, imageSize)
            n = self.wsRef.Shapes.Count;
            copygraphics(axes);
            c = self.getCell(row, column);
            c.PasteSpecial();
            c.RowHeight = imageSize(2);
            c.ColumnWidth = imageSize(1);
            shp = self.wsRef.Shapes.Item(n+1);
            shp.LockAspectRatio = 'msoFalse';
            shp.Width = c.Width;
            shp.Height = c.Height;
            shp.Placement = 'xlMoveandSize';
            shp.Locked = true;
        end
    end
    
    methods (Access = private)
        function c = getCell(self, row, column)
            c = get(self.wsRef, 'Cells', row, column);
        end
        
        function r = getCellRange(self, cell1, cell2)
            r = get(self.wsRef, 'Range', cell1, cell2);
        end
    end
end