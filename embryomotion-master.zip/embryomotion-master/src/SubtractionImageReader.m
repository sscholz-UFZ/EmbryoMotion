classdef SubtractionImageReader < handle
    
    properties (SetAccess = private)
        skippedFrames               (1,1)   double
        blurSigma                   (1,1)   double
    end
    
    properties (Access = private)
        videoReader
        buffer
        useGPU
        p_maximumSubtractionImage  
    end
    
    properties (Dependent)
        duration                    (1,1) double
        imageSize                   (1,2) double
        estimatedFrameCount         (1,1) double
        maximumSubtractionImage
    end
    
    methods
        function self = SubtractionImageReader(videoFile, opts)
            arguments
                videoFile           (1,1) string
                opts.frameDistance  (1,1) double {mustBeInteger, mustBeNonnegative} = 0
                opts.skippedFrames  (1,1) double {mustBeInteger, mustBeNonnegative} = 0
                opts.blurSigma      (1,1) double {mustBeNonnegative} = 0
                opts.useGPU         (1,1) logical = false
            end
            self.videoReader = VideoReader(videoFile);
            self.buffer = RingBuffer(1+opts.frameDistance);
            self.skippedFrames = opts.skippedFrames;
            self.blurSigma = opts.blurSigma;
            self.p_maximumSubtractionImage = uint8(zeros(self.imageSize));
            self.useGPU = opts.useGPU;
            if self.useGPU
                self.p_maximumSubtractionImage = gpuArray(self.p_maximumSubtractionImage);
            end
            for n=0:opts.frameDistance
                self.readNextFrameIntoBuffer();
            end
        end

        function t = get.duration(self)
            t = self.videoReader.Duration;
        end
        
        function sz = get.imageSize(self)
            sz = [self.videoReader.Height, self.videoReader.Width];
        end

        function n = get.estimatedFrameCount(self)
            T = self.videoReader.Duration;
            fps = self.videoReader.FrameRate;
            n = fps*T;
            n = ceil(n / (self.skippedFrames+1));
        end

        function img = get.maximumSubtractionImage(self)
            img = gather(self.p_maximumSubtractionImage);
        end
        
        function [img, time] = next(self)
            lastFrame = self.buffer.getElement(1);
            [frame, time] = self.readNextFrameIntoBuffer();
            img = abs(frame-lastFrame);
            self.p_maximumSubtractionImage = max(self.p_maximumSubtractionImage, img);
        end
    end
    
    methods (Access = private)
        function [frame, time] = readNextFrameIntoBuffer(self)
            for n = 1:self.skippedFrames
            	self.videoReader.readFrame();
            end
            time = self.videoReader.CurrentTime;
            frame = self.videoReader.readFrame();
            if self.useGPU
                frame = gpuArray(frame);
            end
            frame = im2gray(frame);
            if self.blurSigma > 0
                frame = imgaussfilt(frame, self.blurSigma);
            end
            self.buffer = self.buffer.addingElement(frame);
        end
    end
end