classdef MotionProjectVideoMetadata
    
    properties (SetAccess = private)
        file                    (1,1)   string = ""
        name                    (1,1)   string = ""
        path                    (1,1)   string = ""
        duration                (1,1)   double = -1
        framerate               (1,1)   double = -1
        firstFrame
        lastFrame
    end
    
    properties (Dependent)
        frameSize               (1,2)   double
    end
    
    methods
        function self = MotionProjectVideoMetadata(videoFile)
            if nargin < 1 || isempty(videoFile)
                return
            end
            self.file = videoFile;
            try
                vr = VideoReader(videoFile);
                self.name = vr.Name;
                self.path = vr.Path;
                self.duration = vr.Duration;
                self.framerate = vr.FrameRate;
                self.firstFrame = vr.readFrame();
                timePerFrame = 1/vr.FrameRate;
                vr.CurrentTime = vr.Duration;
                while ~vr.hasFrame() && vr.CurrentTime > 0
                    vr.CurrentTime = vr.CurrentTime - timePerFrame;
                end
                self.lastFrame = vr.readFrame();
            catch
            end
        end
        
        function sz = get.frameSize(self)
            sz = size(self.firstFrame);
        end
        
        function tf = checkVideoAvailable(self)
            try
                VideoReader(self.file);
                tf = true;
            catch
                tf = false;
            end
        end
    end
end