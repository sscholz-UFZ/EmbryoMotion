classdef VideoPlayer < handle
    %EMUIVIDEOPLAYER Summary of this class goes here
    %   Detailed explanation goes here
    
    properties (Access = private)
        reader
    end
    
    properties (SetAccess = private)
        frameData
    end
    
    properties (Dependent)
        path                (1,1) string
        filename            (1,1) string
        duration            (1,1) double
        currentTime         (1,1) double
    end
    
    methods
        function self = VideoPlayer(path)
            self.reader = VideoReader(path);
            self.frameData = [];
        end
        
        function val = get.path(self)
            val = string(self.reader.Path);
        end
        
        function val = get.filename(self)
            val = string(self.reader.Name);
        end
        
        function val = get.duration(self)
            val = self.reader.Duration;
        end
        
        function val = get.currentTime(self)
            val = self.reader.CurrentTime;
        end
        
        function scrub(self, value, mode)
            arguments
                self        (1,1) VideoPlayer
                value       (1,1) double
                mode        (1,1) string {mustBeMember(mode, ["time", "progress"])} = "progress"
            end
            if mode == "progress"
                value = value * self.reader.Duration;
            end
            tmax = self.reader.Duration-1/(2*self.reader.FrameRate);
            value = min(tmax, max(0, value));
            self.reader.CurrentTime = value;
            self.readNextFrame();
        end
        
        function tf = isNextFrameAvailable(self)
            arguments
                self        (1,1) VideoPlayer
            end
            tf = self.reader.hasFrame();
        end
        
        function readNextFrame(self)
            arguments
                self        (1,1) VideoPlayer
            end
            self.frameData = self.reader.readFrame();
        end
    end
end

