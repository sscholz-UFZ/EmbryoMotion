classdef Excel < handle
    
    properties (Access = private)
        excelRef
    end
    
    methods
        function self = Excel()
            self.excelRef = actxserver("Excel.Application");
            self.excelRef.Visible = false;
            self.excelRef.DisplayAlerts = false;
        end
        
        function delete(self)
            self.excelRef.Quit();
        end
        
        function wb = createWorkbook(self)
            wbRef = self.excelRef.Workbooks.Add;
            wb = ExcelWorkbook(self, wbRef);
        end
    end
end