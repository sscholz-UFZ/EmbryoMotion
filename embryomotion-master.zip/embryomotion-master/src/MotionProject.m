classdef MotionProject < matlab.mixin.Copyable
    
    properties
        videoMetadata           (1,1)   MotionProjectVideoMetadata
        wellCollection          (1,1)   WellCollection
        motionDetector          (1,1)   MotionDetector = MotionDetector()
        method                  (1,1)   string {mustBeMember(method, ["mean", "max", "min", "sum", "std", "var"])} = "mean"
        experiment              (1,1)   Experiment = Experiment();
    end
    
    methods
        function self = MotionProject(videoFile)
            if nargin < 1
                videoFile = "";
            end
            self.wellCollection = WellCollection();
            self.videoMetadata = MotionProjectVideoMetadata(videoFile);
        end
        
        function result = runAnalysis(self, progressFcn)
            infos = struct("mask", {}, "wellIndex", {}, "embryoIndex", {});
            sz = self.videoMetadata.frameSize;
            [xx, yy] = meshgrid(1:sz(2), 1:sz(1));
            w = self.wellCollection.wells;
            for wellIdx = 1:numel(w)
                well = w(wellIdx);
                for embryoIndex = 1:well.embryoCount
                    embryo = well.embryos(embryoIndex);
                    info.wellIndex = wellIdx;
                    info.embryoIndex = embryoIndex;
                    info.mask = embryo.createMask(xx,yy);
                    infos(end+1) = info;
                end
            end
            masks = cat(3, infos.mask);
            videoFile = self.videoMetadata.file;
            if nargin < 2
                [motionData, maximumSubtractionImage] = self.motionDetector.analyseVideo(videoFile, masks);
            else
                [motionData, maximumSubtractionImage] = self.motionDetector.analyseVideo(videoFile, masks, progressFcn);
            end
            
            result = MotionResult(motionData, maximumSubtractionImage, infos, self);
        end
    end
    
    methods (Access = protected)
        function obj = copyElement(self)
            obj = copyElement@matlab.mixin.Copyable(self);
            obj.wellCollection = self.wellCollection;
        end
    end
end