classdef Well
    
    properties
        name            (1,1) string = ""
        reviewed        (1,1) logical = false
        concentration   (1,1) double = 0
        sortIndex       (1,1) double = 0
    end
    
    properties (SetAccess = private)
        shape           (1,1) polyshape
        shapeID         (1,1) string
        embryos         (1,:) Embryo
    end
    
    properties (Dependent)
        embryoCount
    end
    
    methods
        function self = Well(shape, name)
            if nargin < 2
                name = "";
            end
            self.name = name;
            self.embryos = Embryo.empty;
            self.shape = shape;
            self.shapeID = generateUUID();
        end
        
        function self = addEmbryo(self, x, y, radius)
            embryo = Embryo(x, y, radius);
            self = self.replaceEmbryo(self.embryoCount+1, embryo);
        end
        
        function self = replaceEmbryo(self, idx, newValue)
            if ~self.containsPoint(newValue.x, newValue.y)
                %disp([newValue.x, newValue.y])
                throw(MException("EmbryoMotion:Well:EmbryoCenterOutOfBounds", "Center point out of bounds"));
            end
            self.embryos(idx) = newValue;
        end
        
        function self = removeEmbryo(self, idx)
            self.embryos(idx) = [];
        end
        
        function isInside = containsPoint(self, x, y)
            isInside = self.shape.isinterior(x, y);
        end
        
        function n = get.embryoCount(self)
            n = numel(self.embryos);
        end
    end
end