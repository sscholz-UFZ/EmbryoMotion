classdef WellCollection < matlab.mixin.Copyable
    
    properties (SetAccess = private)
        wells                   (1,:)   Well = Well.empty
    end
    
    properties (Access = private)
        indexMap                        containers.Map
    end
    
    properties (Dependent)
        concentrationRange
    end
    
    
    methods
        function self = WellCollection()
            self.indexMap = containers.Map("KeyType", "char", "ValueType", "double");
        end
        
        function self = update(self, wells)
            if isempty(wells)
                return;
            end
            names = cellstr([wells.name]);
            isMember = self.indexMap.isKey(names);
            indicesToUpdate = cell2mat(self.indexMap.values(names(isMember)));
            self.wells(indicesToUpdate) = wells(isMember);
            wellsToAdd = wells(~isMember);
            if ~isempty(wellsToAdd)
                w = [self.wells, wellsToAdd];
                [~, i] = sort([w.sortIndex]);
                self.wells = w(i);
                self.updateIndexMap();
            end
        end
        
        function removeAtIndex(self, index)
            self.wells(index) = [];
            self.updateIndexMap();
        end
        
        function [w, i] = wellForName(self, name)
            w = Well.empty;
            i = [];
            if self.indexMap.isKey(name)
                i = self.indexMap(name);
                w = self.wells(i);
            end
        end
        
        function c = get.concentrationRange(self)
            c = [self.wells.concentration];
            c(c<0) = nan;
            c = [min(c), max(c)];
        end
        
        function b = hasUnreviewedWells(self)
            b = any(~[self.wells.reviewed], "all");
        end
        
        function readLayoutFile(self, layoutFile)
            o = spreadsheetImportOptions("NumVariables", 2);
            o.VariableNames = ["Well", "Concentration"];
            o = setvaropts(o, "Well", "Type", "string");
            o = setvaropts(o, "Concentration", "Type", "double");
            t = readtable(layoutFile, o);
            wellNames = t.Well;
            c = t.Concentration;
            for idx = 1:numel(wellNames)
                name = wellNames(idx);
                if ~self.indexMap.isKey(name)
                    continue;
                end
                wellIdx = self.indexMap(name);
                well = self.wells(wellIdx);
                if isnan(c(idx))
                    for embryoIdx = 1:well.embryoCount
                        e = well.embryos(embryoIdx);
                        e.valid = false;
                        well = well.replaceEmbryo(embryoIdx, e);
                    end
                end
                well.concentration = abs(c(idx));
                self.wells(wellIdx) = well;
            end
        end
        
        function [w, idx] = nearestWellInDirection(self, x, y, theta, includePoint)
            arguments
                self, x, y, theta, includePoint = false
            end
            % Get the centroid coordinates
            w = self.wells;
            idx = 1:numel(w);
            [cx, cy] = centroid([w.shape]);
            % Shift coordinates so that x,y is at the origin
            cx = cx-x;
            cy = cy-y;
            % Got to polar coordinates
            [phi, rho] = cart2pol(cx,cy);
            if ~includePoint
                k = rho > 2*eps;
                phi = phi(k);
                rho = rho(k);
                w = w(k);
                idx = idx(k);
            end
            % Rotate coodinate system so that the phi-zero axis is along phi
            phi = wrapToPi(phi-theta);
            % Consider only wells in a 2x45° cone of the requested angle
            phi = abs(phi);
            k = phi <= pi/4;
            phi = phi(k);
            rho = rho(k);
            w = w(k);
            idx = idx(k);
            % Compute distance score (between 0 and 1)
            % Give the smallest distance a score of zero
            % and the greates distance a score of 1
            dScore = normalize(rho, "Range");
            % Compute angular score (between 0 and 1)
            aScore = phi/pi;
            % Combine scores (euclidian distance
            score = sqrt(dScore.^2 + aScore.^2);
            % Find lowest score -> Nearest well
            [~, i] = min(score);
            w = w(i);
            idx = idx(i);
        end
    end
    
    methods (Access = protected)
        function obj = copyElement(self)
            obj = copyElement@matlab.mixin.Copyable(self);
            obj.indeMap = copy(self.indexMap);
        end
    end
    
    methods (Access = private)
        function updateIndexMap(self)
            self.indexMap = containers.Map(cellstr([self.wells.name]), 1:numel(self.wells));
        end
    end
    
end