classdef WellDetector
    
    properties
        wellShape                           (1,1) string {mustBeMember(wellShape, ["rectangular", "circular"])} = "rectangular"
        circularWellDetectionSensitivity    (1,1) double {mustBePositive, mustBeLessThanOrEqual(circularWellDetectionSensitivity, 1)} = 0.5
        maxEmbryoCount                      (1,1) double {mustBeInteger, mustBeNonnegative} = 1;
        embryoRadiusRange                   (1,2) double {mustBeNonnegative, mustBeNonNan} = [6,14];
        embryoDetectionSensitivity          (1,1) double {mustBePositive, mustBeLessThanOrEqual(embryoDetectionSensitivity, 1)} = 0.5
    end
    
    methods
        function self = WellDetector()
        end
        
        function wells = detectWells(self, image)
            BW = self.prepareBWImageForAnalysis(image);
            switch self.wellShape
                case "rectangular"
                    wells = self.detectRectangularWells(BW);
                case "circular"
                    wells = self.detectCircularWells(BW, self.circularWellDetectionSensitivity);
            end
            % Detect all embryo candidates
            sens = 0.83 + 0.08 * self.embryoDetectionSensitivity;
            [c, r] = imfindcircles(BW, self.embryoRadiusRange, "Sensitivity", sens, "ObjectPolarity", "dark");
            % Sort by radius
            [r, sorting] = sort(r, "descend");
            c = c(sorting, :);
            % Fill the wells
            for idx = 1:numel(r)
                for wellIdx = 1:numel(wells)
                    well = wells(wellIdx);
                    if well.containsPoint(c(idx,1), c(idx,2))
                        if well.embryoCount < self.maxEmbryoCount
                            wells(wellIdx) = well.addEmbryo(c(idx,1), c(idx,2), r(idx));
                        end
                        break;
                    end
                end
            end
        end
    end
    
    methods (Static, Access = private)
        function BW = prepareBWImageForAnalysis(image)
            if ~ismatrix(image)
                img = rgb2gray(image);
            else
                img = image;
            end
            img = imadjust(img, stretchlim(img, 0.02));
            W = gradientweight(img, "RolloffFactor", 1.25);
            BW = imbinarize(W, "adaptive", "Sensitivity", 0.6);
        end
        
        function wells = detectRectangularWells(BW)
            % prepare return value
            wells = Well.empty;
            % Get the region properties from the binary image
            wellRegions = regionprops(BW, "Area", "Extent", "Eccentricity", "Centroid", "BoundingBox");
            % Filter by geometric properties (so that mostly the well regions remain)
            filter = [wellRegions.Extent] > 0.5 & [wellRegions.Eccentricity] < 0.6 & [wellRegions.Area] > 800;
            wellRegions = wellRegions(filter);
            if isempty(wellRegions)
                return
            end
            % Calculate the mean bounding box size
            wellSize = max(vertcat(wellRegions.BoundingBox));
            wellSize = wellSize(3:4) + 10;
            % Get the center coordinates
            c = vertcat(wellRegions.Centroid);
            % Get mean center values for each row and column
%             cx = getSimiliarMeanValues(c(:,1), wellSize(2)/2);
%             cy = getSimiliarMeanValues(c(:,2), wellSize(1)/2);
            [cx,cy] = centerPointGrid(c, wellSize([2,1])/2);
            % Calculate well coordinates
            x0 = cx - wellSize(1)/2;
            x1 = cx + wellSize(1)/2;
            y0 = cy - wellSize(2)/2;
            y1 = cy + wellSize(2)/2;
            x = [x0, x0, x1, x1];
            y = [y0, y1, y1, y0];
            % Display the same number of digits always
            % This makes sorting easy
            nx = size(x,1);
            ny = size(y,1);
%             format = sprintf("%%c%%0%ii", ceil(log10(max(1,abs(nx)+1))));
            sortIndex = 1;
            for iY = 1:ny
                for iX = 1:nx
                    name = sprintf("%c%i", char('A'-1+iY), iX);
                    w = Well(polyshape(x(iX,:), y(iY,:)), name);
                    w.sortIndex = sortIndex;
                    sortIndex = sortIndex + 1;
                    wells(end+1) = w;
                end
            end
        end
        
        function wells = detectCircularWells(BW, sensModifier)
            sens = 0.85 + 0.1*sensModifier;
            [c, r] = imfindcircles(BW, [50, 100], "ObjectPolarity", "dark", "Sensitivity", sens);
            r = mean(r);
            [cx, cy] = centerPointGrid(c, [r,r]);
            wells = Well.empty;
            nx = size(cx,1);
            ny = size(cy,1);
            sortIndex = 1;
            for iY = 1:ny
                for iX = 1:nx
                    name = sprintf("%c%i", char('A'-1+iY), iX);
                    w = Well(nsidedpoly(50, "Center", [cx(iX), cy(iY)], "Radius", r), name);
                    w.sortIndex = sortIndex;
                    sortIndex = sortIndex + 1;
                    wells(end+1) = w;
                end
            end
        end
    end
end

function [cx,cy] = centerPointGrid(c, h)
if ~isempty(c)
            cx = getSimiliarMeanValues(c(:,1), h(1));
            cy = getSimiliarMeanValues(c(:,2), h(2));
else
    cx = [];
    cy = [];
end
end

% This function returns a list of all means of "near" values (indicated by
% the parameter h
function m = getSimiliarMeanValues(c, h)
% Calculate the distance between each coordinate pair
d = squareform(pdist(c));
% Iterate over all coordinate 'rows'
count = numel(c);
remaining = 1:count;
m = nan(count,1);
mIdx = 1;
while ~isempty(remaining)
    % Find the indices of all elements which have a similiar coordinate as
    % the first one
    elementIdx = find(d(remaining(1),:) < h);
    % Save the mean value
    m(mIdx) = mean(c(elementIdx));
    % Remove the found indices from the remaining indices
    remaining(ismember(remaining, elementIdx)) = [];
    % Advance to the next row
    mIdx = mIdx + 1;
end
% Remove all nan values
m = m(~isnan(m));
% Sort
m = sort(m);
end