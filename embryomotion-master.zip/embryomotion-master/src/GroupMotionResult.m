classdef GroupMotionResult < ProcessedMotionResult
     
    properties
        resultCount
        resultIndex
        peakCountMean
        peakCountSTD
    end
    
    methods
        function self = GroupMotionResult(result, processor, groupIndex)
            self = self@ProcessedMotionResult(result.time, splitapply(@(x) mean(x,1), result.motion, groupIndex), processor);
            self.resultCount = splitapply(@sum, ones(result.count,1), groupIndex);
            self.resultIndex = accumarray(groupIndex, 1:result.count, [], @(x) {x});
        	self.peakCountMean = splitapply(@mean, result.peakCount, groupIndex);
        	self.peakCountSTD = splitapply(@std, result.peakCount, groupIndex);
        end
        
        function self = normalize(self, normalIdx)
            arguments
                self        (1,1) GroupMotionResult
                normalIdx   (1,1) double {mustBeInteger, mustBeNonnegative} = 1
            end
            self = normalize@ProcessedMotionResult(self, normalIdx);
            self.peakCountSTD = self.peakCountSTD / self.peakCountMean(normalIdx);
            self.peakCountMean = self.peakCountMean / self.peakCountMean(normalIdx);
        end
    end
    
    methods (Access = protected)
        function self = extract(self, idx)
            self = extract@ProcessedMotionResult(self, idx);
            self.resultCount = self.resultCount(idx);
            self.resultIndex = self.resultIndex(idx);
            self.peakCountMean = self.peakCountMean(idx);
            self.peakCountSTD = self.peakCountSTD(idx);
        end
    end
end