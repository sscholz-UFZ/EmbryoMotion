classdef MotionDetector

    properties
        frameDistance           (1,1)   double {mustBeInteger, mustBeNonnegative} = 0
        skippedFrames           (1,1)   double {mustBeInteger, mustBeNonnegative} = 0
        blurSigma               (1,1)   double {mustBeNonnegative} = 0
        threshold               (1,1)   double {mustBeInteger, mustBeNonnegative, mustBeLessThan(threshold, 255)} = 5
        method                  (1,1)   string {mustBeMember(method, ["mean", "max", "min", "sum", "std", "var"])} = "mean"
    end

    methods

        function [motionData, maximumSubtractionImage] = analyseVideo(self, videoFile, masks, progressFcn)
            useGPU = canUseGPU();
            imageReader = SubtractionImageReader(videoFile, frameDistance=self.frameDistance, skippedFrames=self.skippedFrames, blurSigma=self.blurSigma, useGPU=useGPU);
            imageSize = imageReader.imageSize;
            needToCheckMaskSize = true;
            if nargin < 3 || isempty(masks)
                % masks = true([imageSize, 1]);
                masks = [];
                needToCheckMaskSize = false;
            end

            numberOfMasks = size(masks, 3);
            estimatedFrameCount = imageReader.estimatedFrameCount;
            time = nan(estimatedFrameCount, 1);
            activePixelCount = nan(estimatedFrameCount, numberOfMasks);
            if useGPU
                activePixelCount = gpuArray(activePixelCount);
                masks = gpuArray(masks);
            end
            frameIdx = 1;
            while true
                try
                    [subtractionImage, t] = imageReader.next();
                catch
                    break
                end
                if needToCheckMaskSize
                    maskSize = size(masks, [1,2]);
                    if ~all(size(maskSize) == size(imageSize)) || ~all(maskSize == imageSize)
                        msgID = "MotionAnalysis:FrameAndMaskSizeNotEqual";
                        msg = "The masks must have the same size as the video frame";
                        throw(MException(msgID, msg));
                    end
                    needToCheckMaskSize = false;
                end
                if nargin > 3
                    progressFcn(t/imageReader.duration);
                end
                time(frameIdx) = t;
                activePixels = subtractionImage > self.threshold;
                % apply masks
                if ~isempty(masks)
                    activePixels = activePixels & masks;
                end
                % update results
                activePixelCount(frameIdx, :) = sum(activePixels, [1,2]);
                frameIdx = frameIdx+1;
            end
            if frameIdx <= estimatedFrameCount
                time(frameIdx:end) = [];
                activePixelCount(frameIdx:end, :) = [];
            end
            if isempty(masks)
                maskPixelCount = reader.FrameHeight * reader.FrameWidth;
            else
                maskPixelCount = reshape(sum(masks, [1,2]), 1, []);
            end
            motionData = MotionData(time, gather(activePixelCount), gather(maskPixelCount));
            maximumSubtractionImage = imageReader.maximumSubtractionImage;
        end
    end
end
