classdef Embryo
    
    properties 
        valid               (1,1) logical   = true
    end
    
    properties (SetAccess = private)
        x                   (1,1) double    = 0
        y                   (1,1) double    = 0
        radius              (1,1) double    = 1
        shape               (1,1) polyshape
        shapeID             (1,1) string
    end
    
    methods
        function self = Embryo(x, y, radius)
            self.x = x;
            self.y = y;
            self.radius = radius;
            self = self.updateShape();
        end
        
        function mask = createMask(self, xx, yy)
            mask = hypot(xx-self.x, yy-self.y) <= self.radius;
        end
        
        function self = moveToPoint(self, x, y)
            self.x = x;
            self.y = y;
            self = self.updateShape();
        end
        
        function self = setRadius(self, r)
            self.radius = r;
            self = self.updateShape();
        end
    end
    
    methods (Access = private)
        function self = updateShape(self)
            self.shape = nsidedpoly(50, "Center", [self.x, self.y], "Radius", self.radius);
            self.shapeID = generateUUID();
        end
    end
end