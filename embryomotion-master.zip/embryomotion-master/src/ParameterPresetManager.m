classdef ParameterPresetManager < handle
    
    properties (SetAccess = private)
        directory           (1,1) string
    end
    
    properties (Access = private)
        presetMap
    end
    
    properties (Dependent)
        presetNames
    end
    
    methods
        function self = ParameterPresetManager(directory)
            self.directory = directory;
            self.presetMap = containers.Map();
            self.addPresetsFromDirectory(directory);
        end
        
        function names = get.presetNames(self)
            names = string(self.presetMap.keys);
        end
        
        function b = isName(self, name)
            b = self.presetMap.isKey(name);
        end
        
        function preset = getPresetForName(self, name)
            preset = self.presetMap(name);
        end
        
        function setPresetForName(self, preset, name)
            self.presetMap(name) = preset;
        end
        
        function removePreset(self, name)
            self.presetMap.remove(name);
        end
        
        function save(self)
            self.savePresetsInDirectory(self.directory)
        end
    end
    
    methods (Access = private)
        function addPresetsFromDirectory(self, folder)
            jsonFiles = dir(fullfile(folder, "*.json"));
            fileCount = numel(jsonFiles);
            for idx = 1:fileCount
                fileInfo = jsonFiles(idx);
                try
                    file = fullfile(fileInfo.folder, fileInfo.name);
                    preset = ParameterPreset.loadFromJson(file);
                catch ME
                    disp(ME);
                    continue
                end
                self.setPresetForName(preset, fileInfo.name(1:end-5));
            end
        end
        
        function savePresetsInDirectory(self, folder)
            if ~isfolder(folder)
                mkdir(folder);
            end
            for name = self.presetNames
               file = fullfile(folder, strcat(name, ".json"));
               preset = self.getPresetForName(name);
               preset.saveAsJson(file);
            end
        end
    end
end