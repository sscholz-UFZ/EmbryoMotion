classdef RingBuffer
    
    properties (SetAccess = private)
        capacity
        count = 0
    end
    
    properties (Access = private)
        data
        startIndex = 1
    end
    
    methods 
        function self = RingBuffer(capacity)
            assert(capacity > 0);
            self.capacity = capacity;
            self.data = cell(capacity,1);
        end
        
        function e = getElement(self, index)
            assert(index <= self.count);
            e = self.data{self.dataIndexOffsetFromStartIndex(index-1)};
        end
        
        function self = addingElement(self, e)
            if self.count < self.capacity
                endIndex = self.dataIndexOffsetFromStartIndex(self.count);
                self.data{endIndex} = e;
                self.count = self.count + 1;
            else
                self.data{self.startIndex} = e;
                self.startIndex = self.dataIndexOffsetFromStartIndex(1);
            end
        end
    end
    
    methods (Access = private)
        function idx = dataIndexForUnboundedIndex(self, idx)
            idx = mod(idx-1, self.capacity) + 1;
        end
        
        function idx = dataIndexOffsetFromStartIndex(self, offset)
            idx = self.dataIndexForUnboundedIndex(self.startIndex+offset);
        end
    end
end