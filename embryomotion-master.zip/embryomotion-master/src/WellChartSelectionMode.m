classdef WellChartSelectionMode
    enumeration
        none, single, multi
    end
end