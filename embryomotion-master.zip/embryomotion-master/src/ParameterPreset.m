classdef ParameterPreset
    
    properties
        skippedFrames           (1,1)   double {mustBeInteger, mustBeNonnegative} = 0
        frameDistance           (1,1)   double {mustBeInteger, mustBeNonnegative} = 0
        blurFilterSigma         (1,1)   double {mustBeNonnegative} = 0
        motionThreshold         (1,1)   double {mustBeInteger, mustBeNonnegative, mustBeLessThan(motionThreshold, 255)} = 5
        method                  (1,1)   string {mustBeMember(method, ["mean", "max", "min", "sum", "std", "var"])} = "mean"
        binTime                 (1,1)   double {mustBeNonnegative} = 0.5
    end
    
    methods
        function saveAsJson(self, file)
            json.skippedFrames = self.skippedFrames;
            json.frameDistance = self.frameDistance;
            json.blurSigma = self.blurFilterSigma;
            json.motionThreshold = self.motionThreshold;
            json.method = self.method;
            json.binTime = self.binTime;
            fid = fopen(file, "w");
            fprintf(fid, "%s", jsonencode(json));
            fclose(fid);
        end
    end
    
    methods (Static)
        function preset = loadFromJson(file)
            preset = ParameterPreset();
            json = jsondecode(fileread(file));
            preset.skippedFrames = json.skippedFrames;
            preset.frameDistance = json.frameDistance;
            preset.blurFilterSigma = json.blurSigma;
            preset.motionThreshold = json.motionThreshold;
            preset.method = json.method;
            preset.binTime = json.binTime;
        end
    end
end