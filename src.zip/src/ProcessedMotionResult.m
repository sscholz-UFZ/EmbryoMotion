classdef ProcessedMotionResult
    
    properties (SetAccess = private)
        time
        motion
        fittedTime
        fittedMotion
        isPeak
        peakCount
        maxPeakValue
        maxPeakTime
        lag
        excitation
        refractory
    end
    
    properties (Dependent)
        count
    end
    
    methods
        function self = ProcessedMotionResult(time, motion, processor)
            arguments
                time        (1,:) double
                motion      (:,:) double
                processor   (1,1) MotionPostProcessor
            end
            self.time = time;
            self.motion = motion;
            [self.fittedTime, self.fittedMotion] = processor.fitMotion(time, motion, 1000);
            [self.isPeak, self.peakCount, self.maxPeakValue, self.maxPeakTime] = processor.findPeaks(self.fittedTime, self.fittedMotion);
            [self.lag, self.excitation, self.refractory] = processor.calculatePhaseMeans(self.fittedTime, self.fittedMotion);
        end
        
        function n = get.count(self)
            n = size(self.motion, 1);
        end
        
        function self = normalize(self, normalIdx)
            arguments
                self        (1,1) ProcessedMotionResult
                normalIdx   (1,1) double {mustBeInteger, mustBeNonnegative} = 1
            end
            self.motion = self.motion ./ self.motion(normalIdx,:);
            self.fittedMotion = self.fittedMotion ./ self.fittedMotion(normalIdx,:);
            self.peakCount = self.peakCount / self.peakCount(normalIdx);
            self.maxPeakValue = self.maxPeakValue / self.maxPeakValue(normalIdx);
            self.maxPeakTime = self.maxPeakTime / self.maxPeakTime(normalIdx);
            self.refractory = self.refractory / self.lag(normalIdx);
            self.lag = self.lag / self.lag(normalIdx);
            self.excitation = self.excitation / self.excitation(normalIdx);
        end
        
        % Custom subscripting
        function sref = subsref(self,s)
            switch s(1).type
                case '.'
                    sref = builtin('subsref',self,s);
                case '()'
                    subs = s(1).subs;
                    if numel(subs) > 1
                        error('ProcessedMotionResult:subsref', 'Not a linear index')
                    end
                    idx = [subs{:}];
                    sref = self.extract(idx);
                    if length(s) > 1
                        sref = builtin('subsref',sref,s(2:end));
                    end
                case '{}'
                    error('ProcessedMotionResult:subsref', 'Not a supported subscripted reference')
            end
        end
    end
    
    methods (Access = protected)
        function self = extract(self, idx)
            arguments
                self    (1,1) ProcessedMotionResult
                idx     (1,:) double {mustBeInteger, mustBeNonnegative}
            end
            self.motion = self.motion(idx,:);
            self.fittedMotion = self.fittedMotion(idx,:);
            self.isPeak = self.isPeak(idx,:);
            self.peakCount = self.peakCount(idx);
            self.maxPeakValue = self.maxPeakValue(idx);
            self.maxPeakTime = self.maxPeakTime(idx);
            self.lag = self.lag(idx);
            self.excitation = self.excitation(idx);
            self.refractory = self.refractory(idx);
        end
    end
end