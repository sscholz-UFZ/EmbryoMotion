classdef WellChart < matlab.graphics.chartcontainer.ChartContainer
    
    properties
        % Selection
        wellSelectionMode           (1,1)   WellChartSelectionMode = WellChartSelectionMode.none
        embryoSelectionMode         (1,1)   WellChartSelectionMode = WellChartSelectionMode.none
        % Styling
        colors                      (1,1)   WellPlotColors = WellPlotColors();
        % Context menus
        backgroundContextMenu
        wellContextMenu
        embryoContextMenu
    end
    
    properties (Access = private, Transient, NonCopyable)
        backgroundPlot
        wellPlots                    (1,:) 	SingleWellPlot = SingleWellPlot.empty;
    end
    
    properties (Dependent)
        backgroundImage
        wells
        selectedWells
        selectedEmbryos
        highlightedEmbryos
        CurrentPoint
        isZoomed
    end
    
    events
        WellSelection
        EmbryoSelection
    end
    
    methods
        function img = get.backgroundImage(self)
            img = self.backgroundPlot.CData;
        end
        
        function set.backgroundImage(self, newValue)
            self.backgroundPlot.CData = newValue;
        end
        
        function w = get.wells(self)
            wp = self.wellPlots();
            w = [wp.well];
        end
        
        function set.wells(self, newValue)
            n = numel(newValue);
            np = numel(self.wellPlots);
            if n < np
                iW = (n+1):np;
                delete(self.wellPlots(iW));
                self.wellPlots(iW) = [];
            end
            a = self.getAxes();
            for iW = 1:n
                w = newValue(iW);
                if iW > np || ~isvalid(self.wellPlots(iW))
                    p = SingleWellPlot(a, w, @(~) self.wellButtonDown(iW), @(~, iE) self.embryoButtonDown(iW, iE));
                    self.wellPlots(iW) = p;
                else
                    self.wellPlots(iW).well = w;
                end
            end
        end
        
        function s = get.selectedWells(self)
            wp = self.wellPlots;
            s = find([wp.selected]);
        end
        
        function set.selectedWells(self, newValue)
            n = numel(self.wellPlots);
            isSelected = ismember(1:n, newValue);
            for iW = 1:n
                wp = self.wellPlots(iW);
                wp.selected = isSelected(iW);
            end
        end
        
        function s = get.selectedEmbryos(self)
            wp = self.wellPlots;
            s = {wp.selectedEmbryos};
        end
        
        function set.selectedEmbryos(self, newValue)
            validateattributes(newValue, 'cell', {'vector', 'numel', numel(self.wellPlots)});
            for iW = 1:numel(self.wellPlots)
                self.wellPlots(iW).selectedEmbryos = newValue{iW};
            end
        end
        
        function s = get.highlightedEmbryos(self)
            wp = self.wellPlots;
            s = {wp.highlightedEmbryos};
        end
        
        function set.highlightedEmbryos(self, newValue)
            validateattributes(newValue, 'cell', {'vector', 'numel', numel(self.wellPlots)});
            for iW = 1:numel(self.wellPlots)
                self.wellPlots(iW).highlightedEmbryos = newValue{iW};
            end
        end
        
        function p = get.CurrentPoint(self)
            p = self.getAxes().CurrentPoint;
        end
        
        function tf = get.isZoomed(self)
            ax = self.getAxes();
            imageLimits = [self.backgroundPlot.XData, self.backgroundPlot.YData];
            axisLimits = [ax.XLim, ax.YLim];
            tf = ~isequal(imageLimits, axisLimits);
        end
        
        function zoom(self, wellIdx, buffer)
            ax = self.getAxes();
            if nargin < 2
                if isempty(self.backgroundImage)
                    wellIdx = 1:numel(self.wells);
                else
                    ax.XLim = self.backgroundPlot.XData;
                    ax.YLim = self.backgroundPlot.YData;
                    return
                end
            end
            if nargin < 3
                buffer = 20;
            end
            if isempty(wellIdx)
                %xlim = [0,1];
                %ylim = [0,1];
                xlim = self.backgroundPlot.XData;
                ylim = self.backgroundPlot.YData;
            else
                w = self.wells(wellIdx);
                unifiedShape = union([w.shape]);
                bufferedShape = polybuffer(unifiedShape, buffer);
                [xlim, ylim] = boundingbox(bufferedShape);
            end
            ax.XLim = xlim;
            ax.YLim = ylim;
        end
    end
    
    methods (Access = protected)
        function setup(self)
            ax = self.getAxes();
            self.backgroundPlot = imshow([], "Parent", ax);
            self.backgroundPlot.ButtonDownFcn = @(~,~) self.backgroundButtonDown();
        end
        
        function update(self)
            ax = self.getAxes();
            ax.Interactions = [];
            ax.Toolbar = [];
            hold(ax, "on");
            self.backgroundPlot.ContextMenu = self.backgroundContextMenu;
            for iW = 1:numel(self.wellPlots)
                wp = self.wellPlots(iW);
                wp.colors = self.colors;
                wp.wellContextMenu = self.wellContextMenu;
                wp.embryoContextMenu = self.embryoContextMenu;
                wp.update();
            end
            hold(ax, "off");
        end
    end
    
    methods (Access = private)
        function backgroundButtonDown(self)
            if self.wellSelectionMode == WellChartSelectionMode.single || self.wellSelectionMode == WellChartSelectionMode.multi
                self.selectedWells = [];
                notify(self, "WellSelection");
            end
        end
        
        function wellButtonDown(self, wellIdx)
            if wellIdx > numel(self.wells)
                return;
            end
            switch self.wellSelectionMode
                case WellChartSelectionMode.none
                    return
                case WellChartSelectionMode.single
                    if ismember(wellIdx, self.selectedWells)
                        self.selectedWells = [];
                    else
                        self.selectedWells = wellIdx;
                    end
                case WellChartSelectionMode.multi
                    [isSelected, index] = ismember(wellIdx, self.selectedWells);
                    if isSelected
                        self.selectedWells(index) = [];
                    else
                        self.selectedWells = unique([self.selectedWells, wellIdx]);
                    end
            end
            notify(self, "WellSelection")
        end
        
        function embryoButtonDown(self, wellIdx, embryoIdx)
            switch self.embryoSelectionMode
                case WellChartSelectionMode.none
                    self.wellButtonDown(wellIdx);
                    return
                case WellChartSelectionMode.single
                    s = self.selectedEmbryos{wellIdx};
                    isSelected = ismember(embryoIdx, s);
                    if isSelected
                        self.selectedEmbryos{wellIdx} = [];
                    else
                        self.selectedEmbryos{wellIdx} = embryoIdx;
                    end
                case WellChartSelectionMode.multi
                    s = self.selectedEmbryos{wellIdx};
                    [isSelected, index] = ismember(embryoIdx, s);
                    if isSelected
                        s(index) = [];
                    else
                        s(end+1) = embryoIdx;
                    end
                    self.selectedEmbryos{wellIdx} = s;
            end
            self.update();
            notify(self, "EmbryoSelection")
        end
    end
end
