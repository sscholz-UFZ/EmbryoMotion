function uuid = generateUUID()
temp =  java.util.UUID.randomUUID;
uuid = string(temp.toString);
end