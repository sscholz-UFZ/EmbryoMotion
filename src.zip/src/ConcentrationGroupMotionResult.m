classdef ConcentrationGroupMotionResult < GroupMotionResult
    
    properties (SetAccess = private)
        concentration
    end

    
    methods
        function self = ConcentrationGroupMotionResult(embryoMotionResult, processor)
            n = embryoMotionResult.count;
            c = nan(n,1);
            for idx = 1:n
                well = embryoMotionResult.well(idx);
                embryo = well.embryos(embryoMotionResult.embryoIndex(idx));
                if ~embryo.valid
                    c(idx) = nan;
                else
                    c(idx) = well.concentration;
                end
            end
            c(isnan(c)) = -1;
            [groupIndex, groupIDs] = findgroups(c);
            self = self@GroupMotionResult(embryoMotionResult, processor, groupIndex);
            self.concentration = groupIDs;
        end
    end
    
    methods (Access = protected)
        function self = extract(self, idx)
            self = extract@GroupMotionResult(self, idx);
            self.concentration = self.concentration(idx);
        end
    end
    
    methods (Access = private)
        function idx = defaultNormalizationIndex(self)
            idx = find(self.concentration == 0, 1);
            if isempty(idx)
                idx = 1;
            end
        end
    end
end