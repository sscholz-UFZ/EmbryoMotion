classdef WellGroupMotionResult < GroupMotionResult
    
    properties (SetAccess = private)
        well
    end

    
    methods
        function self = WellGroupMotionResult(embryoMotionResult, processor)
            wells = [embryoMotionResult.well];
            sortIndex = [wells.sortIndex];
            groupIndex = findgroups(sortIndex);
            groupIndex = reshape(groupIndex, [], 1);
            self = self@GroupMotionResult(embryoMotionResult, processor, groupIndex);
            self.well = cellfun(@(x) embryoMotionResult(x(1)).well, self.resultIndex);
        end
    end
    
    methods (Access = protected)
        function self = extract(self, idx)
            self = extract@GroupMotionResult(self, idx);
            self.well = self.well(idx);
        end
    end
end