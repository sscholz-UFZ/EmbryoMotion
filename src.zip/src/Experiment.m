classdef Experiment
    properties
        substance               (1,1)   string = ""
        date                    (1,1)   datetime = datetime
        replica                 (1,1)   string = ""
        person                  (1,1)   string = ""
    end
end