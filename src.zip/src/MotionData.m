classdef MotionData
    properties (SetAccess = private)
        time                (:,1) double
        regionPixelCount    (1,:) double
        activePixelCount    (:,:) double
    end

    properties (Dependent)
        numTimes            (1,1) double
        numRegions          (1,1) double
        max                 (:,:) double
        min                 (:,:) double
        mean                (:,:) double
        var                 (:,:) double
        std                 (:,:) double
    end
    
    methods
        function self = MotionData(time, activePixelCount, regionPixelCount)
            arguments
                time                (:,1) double    % recorded timestamps
                activePixelCount    (:,:) double    % number of active pixels
                regionPixelCount    (1,:) double    % number of pixels per region
            end
            n = numel(time);
            m = numel(regionPixelCount);
            assert(all(size(activePixelCount) == [n,m]));
            self.time = time;
            self.activePixelCount = activePixelCount;
            self.regionPixelCount = regionPixelCount;
        end
        
        function val = get.numTimes(self)
            val = numel(self.time);
        end
 
       function val = get.numRegions(self)
            val = numel(self.regionPixelCount);
        end

        function val = get.max(self)
            val = double(self.activePixelCount > 0);
        end

        function val = get.min(self)
            val = double(self.activePixelCount == self.regionPixelCount);
        end

        function val = get.mean(self)
            val = self.activePixelCount ./ self.regionPixelCount;
        end

        function val = get.var(self)
            % specialised calculation for binary distributions
            c = 1 ./ (self.regionPixelCount-1);
            m = self.mean;
            a = m.^2 .* c .* self.regionPixelCount;
            b = (1 - 2*m) .* c .* self.activePixelCount;
            val = a+b;
        end

        function val = get.std(self)
            val = sqrt(self.var);
        end
    end
end

