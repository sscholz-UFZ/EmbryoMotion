classdef EmbryoMotionResult < ProcessedMotionResult
    
    properties (SetAccess = private)
        well
        embryoIndex
    end
    
    methods
        function self = EmbryoMotionResult(time, motion, well, embryoIndex, processor)
            arguments
                time            (1,:) double
                motion          (:,:) double
                well            (1,:) Well
                embryoIndex     (1,:) double
                processor       (1,1) MotionPostProcessor
            end
            [bt, bm] = processor.binMotion(time, motion);
            self = self@ProcessedMotionResult(bt, bm, processor);
            self.well = well;
            self.embryoIndex = embryoIndex;
        end
    end
    
    methods (Access = protected)
        function self = extract(self, idx)
            self = extract@ProcessedMotionResult(self, idx);
            self.well = self.well(idx);
            self.embryoIndex = self.embryoIndex(idx);
        end
    end
end

