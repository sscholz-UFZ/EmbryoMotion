classdef MotionResultExcelExporter

    properties
        motionResult        MotionResult
        plotImageSize       (1,2) double {mustBeGreaterThan(plotImageSize, 0), mustBeInteger} = [60 200]    % width*height in weird excel format
        mode                (1,1) string {mustBeMember(mode, ["full", "pmr", "stc"])} = "full"
    end

    methods
        function self = MotionResultExcelExporter(motionResult)
            self.motionResult = motionResult;
        end

        function exportToFullpath(self, file)
            % Open Excel
            excel = Excel();
            % Create Workbook
            wb = excel.createWorkbook();
            self.writeEmbryoResults(wb);
            self.writeConcentrationResults(wb);
            self.writeMeanResults(wb);
            self.writeImagePlots(wb);
            self.writeInfos(wb);
            % Save file
            wb.saveAs(file);
        end
    end

    methods (Access = private)
        function writeEmbryoResults(self, wb)
            % Write motion data

            r = self.motionResult.embryoResult;
            wells = r.well;
            labels = num2cell([wells.name] + "-" + string(r.embryoIndex));
            labels = reshape(labels, [], 1);
            data = ['EmbryoLabel \\ Time (s)', num2cell(r.time); labels, num2cell(r.motion)];
            ws = wb.addSheet();
            ws.name = "Embryo Motion Data";
            self.writeExcelMotionPlots(ws, r.time, r.motion, 2, 1, self.plotImageSize);
            ws.writeValues(data, 1, 2);
            % Write important results
            c = self.concentrationLabels([wells.concentration]);
            names = {'Embryo Label', 'Concentration', 'Lag', 'Excitation', 'Refractory', 'Peak Count', 'Max Peak Value', 'Max Peak Time'};
            data = num2cell([r.lag, r.excitation, r.refractory, r.peakCount, r.maxPeakValue, r.maxPeakTime]);
            data = [labels, c, data];
            data = [names;data];
            if self.mode == "pmr"
                data(:,[6,7,8]) = [];
            elseif self.mode == "stc"
                data(:,[3,4,5]) = [];
            end
            ws = wb.addSheet();
            ws.name = "Embryo Results";
            ws.writeValues(data, 1, 1);
        end

        function writeConcentrationResults(self, wb)
            % Write motion data
            r = self.motionResult.concentrationResult;
            labels = self.concentrationLabels(r.concentration);
            data = ['Concentration \\ Time (s)', num2cell(r.time); labels, num2cell(r.motion)];
            ws = wb.addSheet();
            ws.name = "Concentration Motion Data";
            self.writeExcelMotionPlots(ws, r.time, r.motion, 2, 1, self.plotImageSize);
            ws.writeValues(data, 1, 2);
            % Write important results
            names = {'Concentration', 'EmbryoCount', 'Lag', 'Excitation', 'Refractory', 'Peak Count Mean', 'Peak Count STD'};
            data = num2cell([reshape(r.resultCount, [],1), r.lag, r.excitation, r.refractory, r.peakCountMean, r.peakCountSTD]);
            data = [labels, data];
            data = [names;data];
            if self.mode == "pmr"
                data(:,[6,7]) = [];
            elseif self.mode == "stc"
                data(:,[3,4,5]) = [];
            end
            ws = wb.addSheet();
            ws.name = "Concentration Results";
            ws.writeValues(data, 1, 1);

            if self.mode ~= "pmr"
                f = figure("Visible", false);
                ax = axes(f);
                barh(ax, r.peakCountMean);
                ax.YTickLabel = labels;
                title(ax, "Mean Peak Count / Concentration");
                ws.writePlotImage(ax, size(data, 1)+2, 3, self.plotImageSize);
                delete(f);
            end
        end

        function writeMeanResults(self, wb)
            % Write motion data
            ws = wb.addSheet();
            ws.name = "Mean Motion Data";
            r = self.motionResult.meanResult;
            data = ['Time (s)', num2cell(r.fittedTime); 'Mean Motion', num2cell(r.fittedMotion)];
            self.writeExcelMotionPlots(ws, r.fittedTime, r.fittedMotion, 2, 1, self.plotImageSize);
            ws.writeValues(data, 1, 2);
            %             ws = wb.Worksheets.Add;
            %             ws.name = "Mean Results";
            %             names = {'Lag', 'Excitation', 'Refractory', 'Peak Count', 'Max Peak Value', 'Max Peak Time'};
            %             data = num2cell([r.lag, r.excitation, r.refractory, r.peakCount, r.maxPeakValue, r.maxPeakTime]);
            %             data = [names;data];
            %             self.writeExcelCellValues(ws, data);
        end

        function writeImagePlots(self, wb)
            ws = wb.addSheet();
            ws.name = "Images";
            ws.writeValues({'First Frame', 'SubtractionImage (x10)', 'Masks'}, 1, 1);
            f = figure("Visible", false);
            ax = axes(f);
            imshow(self.motionResult.videoMetadata.firstFrame, "Parent", ax);
            ws.writePlotImage(ax, 2,1, self.plotImageSize);
            imshow(self.motionResult.maximumSubtractionImage*10, "Parent", ax);
            ws.writePlotImage(ax, 2,2, self.plotImageSize);
            imshow(rescale(self.motionResult.maskedSubtractionImage, 0, 255), "Parent", ax);
            ws.writePlotImage(ax, 2,3, self.plotImageSize);
            delete(f);
        end

        function writeInfos(self, wb)
            ws = wb.addSheet();
            ws.name = "Info";
            row = 1;
            md = self.motionResult.experiment;
            c = self.motionResult.concentrationRange;
            data = {'Experiment Info', nan; ...
                'Substance', md.substance; ...
                'Concentration Range', sprintf("%f - %f", c(1),c(2)); ...
                'Replica', md.replica; ...
                'Date', md.date; ...
                'Person', md.person};
            ws.writeValues(data, row, 1);
            row = row + size(data,1) + 1;
            md = self.motionResult.videoMetadata;
            data = {'Video Info', nan; ...
                'Video Path', md.file; ...
                'Video name', md.name; ...
                'Video Duration', md.duration; ...
                'Video Framerate', md.framerate};
            ws.writeValues(data, row, 1);
            row = row + size(data,1) + 1;
            md = self.motionResult.motionDetector;
            data = {'Motion Detection Parameters', nan; ...
                'Skipped Frames', md.skippedFrames; ...
                'Frame Distance', md.frameDistance; ...
                'Blur', md.blurSigma; ...
                'Threshold', md.threshold; ...
                'Method', md.method};
            ws.writeValues(data, row, 1);
            row = row + size(data,1) + 1;
            md = self.motionResult.postProcessor;
            data = {'Post Processing Parameters', nan; ...
                'Bin Time', md.binTime; ...
                'Lag Time', md.lagTime; ...
                'Excitation Time', md.excitationTime};
            ws.writeValues(data, row, 1);
        end
    end

    methods (Static, Access = private)
        function writeExcelMotionPlots(ws, time, motion, row, column, imageSize)
            f = figure("Visible", false);
            ax = axes(f);
            for idx = 1:size(motion,1)
                plot(ax, time, motion(idx,:));
                ws.writePlotImage(ax, row+idx-1, column, imageSize)
            end
            delete(f);
        end

        function l = concentrationLabels(c)
            l = num2cell(string(c));
            l(c<0 | isnan(c)) = {'Dead/ invalid'};
            l = reshape(l, [], 1);
        end
    end
end

