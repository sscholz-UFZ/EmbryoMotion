classdef WellPlotColors
    properties
        wellColor = [244 226 133] ./ 255
        wellAlpha = 0.2
        reviewedWellColor = [140 179 105] ./ 255
        reviewedWellAlpha = 0.5
        selectedWellBorderColor = [0 114 189] ./ 255
        embryoColor = [0 0 0] ./ 255
        embryoAlpha = 0.01
        invalidEmbryoColor = [188 75 81] ./ 255
        invalidEmbryoAlpha = 0.5
        embryoHighlightColor = [202 232 232] ./ 255
        selectedEmbryoAlpha = 0.15
    end
end