classdef SingleWellPlot < handle
    
    properties
        well                (1,1) Well = Well(polyshape);
        % Selection state
        selected            (1,1) logical = false
        selectedEmbryos     (1,:) double = []
        highlightedEmbryos  (1,:) double = []
        % Styling
        colors              (1,1) WellPlotColors = WellPlotColors()
        % Context Menus
        wellContextMenu
        embryoContextMenu
    end
    
    properties (SetAccess = private)
        wellButtonDownFcn   function_handle
        embryoButtonDownFcn function_handle
    end
    
    properties (Access = private)
        axes
        wellShapePlot           matlab.graphics.primitive.Polygon
        embryoShapePlots        matlab.graphics.primitive.Polygon
        plottedWellShapeID  	string
        plottedEmbryoShapeIDs   string
    end
    
    methods
        function self = SingleWellPlot(ax, well, wellButtonDownFcn, embryoButtonDownFcn)
            self.axes = ax;
            self.well = well;
            self.wellButtonDownFcn = wellButtonDownFcn;
            self.embryoButtonDownFcn = embryoButtonDownFcn;
        end
        
        function delete(self)
            delete(self.wellShapePlot);
            delete(self.embryoShapePlots);
        end
        
        function update(self)
            self.updateWellShapePlot();
            self.updateEmbryoShapePlots();
        end
    end
    
    methods (Access = private)
        function updateWellShapePlot(self)
            if isempty(self.wellShapePlot) || ~isvalid(self.wellShapePlot)
                self.wellShapePlot = plot(self.axes, self.well.shape);
                self.plottedWellShapeID = self.well.shapeID;
                if isempty(self.wellButtonDownFcn)
                    f = [];
                else
                    f = @(~,~) self.wellButtonDownFcn(self);
                end
                self.wellShapePlot.ButtonDownFcn = f;
            elseif self.plottedWellShapeID ~= self.well.shapeID
                self.wellShapePlot.Shape = self.well.shape;
                self.plottedWellShapeID = self.well.shapeID;
            end
            if self.well.reviewed
                fc = self.colors.reviewedWellColor;
                ec = self.colors.reviewedWellColor;
                fa = self.colors.reviewedWellAlpha;
            else
                fc = self.colors.wellColor;
                ec = self.colors.wellColor;
                fa = self.colors.wellAlpha;
            end
            if self.selected
                ec = self.colors.selectedWellBorderColor;
                lw = 2.5;
            else
                lw = 1.5;
            end
            self.applyStyleToPlot(self.wellShapePlot, fc, fa, ec, lw);
            self.wellShapePlot.ContextMenu = self.wellContextMenu;
        end
        
        function updateEmbryoShapePlots(self)
            n = self.well.embryoCount();
            nep = numel(self.embryoShapePlots);
            isSelected = ismember(1:n, self.selectedEmbryos);
            isHighlighted = ismember(1:n, self.highlightedEmbryos);
            for iE = 1:n
                e = self.well.embryos(iE);
                if iE > nep || ~isvalid(self.embryoShapePlots(iE))
                    self.embryoShapePlots(iE) = plot(self.axes, e.shape);
                    self.plottedEmbryoShapeIDs(iE) = e.shapeID;
                    if isempty(self.embryoButtonDownFcn)
                        f = [];
                    else
                        f = @(~,~) self.embryoButtonDownFcn(self, iE);
                    end
                    self.embryoShapePlots(iE).ButtonDownFcn = f;
                elseif self.plottedEmbryoShapeIDs(iE) ~= e.shapeID
                    self.embryoShapePlots(iE).Shape = e.shape;
                    self.plottedEmbryoShapeIDs(iE) = e.shapeID;
                end
                if e.valid
                    fc = self.colors.embryoColor;
                    fa = self.colors.embryoAlpha;
                else
                    fc = self.colors.invalidEmbryoColor;
                    fa = self.colors.invalidEmbryoAlpha;
                end
                if isSelected(iE)
                    fa = self.colors.selectedEmbryoAlpha;
                end
                if isHighlighted(iE)
                    ec = self.colors.embryoHighlightColor;
                elseif fa == 0
                    ec = "none";
                else
                    ec = fc;
                end
                self.applyStyleToPlot(self.embryoShapePlots(iE), fc, fa, ec);
                self.embryoShapePlots(iE).ContextMenu = self.embryoContextMenu;
            end
            idx = (n+1):nep;
            delete(self.embryoShapePlots(idx));
            self.embryoShapePlots(idx) = [];
        end
    end
    
    methods (Static, Access = private)
        function applyStyleToPlot(p, fc, fa, ec, lw)
            if ~isequal(fc, p.FaceColor)
                p.FaceColor = fc;
            end
            if ~isequal(fa, p.FaceAlpha)
                p.FaceAlpha = fa;
            end
            if ~isequal(ec, p.EdgeColor)
                p.EdgeColor = ec;
            end
            if nargin >= 5 && p.LineWidth ~= lw
                p.LineWidth = lw;
            end
        end
    end
end