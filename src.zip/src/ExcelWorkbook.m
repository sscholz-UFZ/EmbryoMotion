classdef ExcelWorkbook < handle
    
    properties (SetAccess = private)
        excel               Excel
    end
    
    properties (Access = private)
        wbRef
    end
    
    methods (Access = {?Excel})
        function self = ExcelWorkbook(excel, wbRef)
            self.excel = excel;
            self.wbRef = wbRef;
        end
    end
    
    methods
        function delete(self)
            self.wbRef.Close();
        end
        
        function ws = addSheet(self)
            wsRef = self.wbRef.Worksheets.Add;
            ws = ExcelWorksheet(self, wsRef);
        end
        
        % Only works with absolute paths
        function saveAs(self, filename)
            self.wbRef.SaveAs(filename);
        end
    end
end