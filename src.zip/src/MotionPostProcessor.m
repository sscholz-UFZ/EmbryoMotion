classdef MotionPostProcessor
    
    properties
        binTime = 0.5
        fitTimesCount = 1000;
        lagTime = [-Inf, 20];
        excitationTime = [21, 25];
        refractoryTime = [31, 35];
    end
    
    methods
        function [time, motion] = binMotion(self, time, motion)
            t = time;
            m = motion;
            bt = 0:self.binTime:t(end);
            binCount = numel(bt);
            bm = nan(size(m,1), binCount);
            bm(:,1) = 0;
            idx = 1;
            start = 1;
            for bin = 2:binCount
                while t(idx) <= bt(bin) && idx < numel(t) 
                    idx = idx + 1;
                end
                bm(:,bin) = mean(m(:,start:idx-1),2);
                start = idx;
            end
            time = bt;
            motion = bm;
        end
        
        function [lag, ex, ref] = calculatePhaseMeans(self, time, motion)
            isLag = time >= self.lagTime(1) & time <= self.lagTime(2);
            lag = mean(motion(:, isLag), 2);
            isEx = time >= self.excitationTime(1) & time <= self.excitationTime(2);
            ex = mean(motion(:, isEx), 2);
            isRef = time >= self.refractoryTime(1) & time <= self.refractoryTime(2);
            ref = mean(motion(:, isRef), 2);
        end
    end
    
    methods (Static)
        function [time, motion] = fitMotion(time, motion, n)
            t = time';
            m = motion';
            time = linspace(t(1), t(end), n);
            m = interp1(t, m, time', "makima");
            m(m<0) = 0;
            motion = m';
        end
        
        function [isPeak, count, maxValue, maxTime] = findPeaks(time, motion)
            [p, prom] = islocalmax(motion, 2, "SamplePoints", time);
            isPeak = p & prom > 0.0008;
            count = sum(isPeak, 2);
            motion(~isPeak) = 0;
            [maxValue, i] = max(motion, [], 2);
            maxTime = time(i)';
        end
    end
end