classdef MotionResult < handle
    
    properties (SetAccess = private)
        maximumSubtractionImage
        embryoResult            EmbryoMotionResult
        meanResult              ProcessedMotionResult
        concentrationResult     ConcentrationGroupMotionResult
        wellResult              WellGroupMotionResult
    end
    
    properties (Access = private)
        motionData          MotionData
        
        processor           (1,1) MotionPostProcessor = MotionPostProcessor()
        project
        infos
    end
    
    properties (Dependent)
        wells
        videoMetadata
        experiment
        motionDetector
        method              (1,1)   string {mustBeMember(method, ["mean", "max", "min", "sum", "std", "var"])}
        postProcessor
        concentrationRange
        maskedSubtractionImage
        time
        motion
    end
    
    methods
        function self = MotionResult(motionData, maximumSubtractionImage, infos, project)
            self.motionData = motionData;
            self.maximumSubtractionImage = maximumSubtractionImage;
            self.project = copy(project);
            self.infos = infos;
            self.updateResults();
        end
    end
    
    methods
        function w = get.wells(self)
            w = self.project.wellCollection.wells;
        end
        
        function p = get.videoMetadata(self)
            p = self.project.videoMetadata;
        end
        
        function p = get.experiment(self)
            p = self.project.experiment;
        end
        
        function set.experiment(self, newValue)
            self.project.experiment = newValue; 
        end
        
        function p = get.motionDetector(self)
            p = self.project.motionDetector;
        end

        function m = get.method(self)
            m = self.project.method;
        end

        function set.method(self, newValue)
            self.project.method = newValue;
            self.updateResults();
        end
        
        function p = get.postProcessor(self)
            p = self.processor;
        end
        
        function set.postProcessor(self, newValue)
            self.processor = newValue;
            self.updateResults();
        end
        
        function c = get.concentrationRange(self)
            c = self.project.wellCollection.concentrationRange;
        end
        
        function img = get.maskedSubtractionImage(self)
            m = zeros(size(self.maximumSubtractionImage));
            for idx = 1:numel(self.infos)
                m = m | self.infos(idx).mask;
            end
            img = self.maximumSubtractionImage;
            img(~m) = 0;
        end

        function t = get.time(self)
            t = self.motionData.time';
        end

        function m = get.motion(self)
            switch self.method
                case "mean"
                    m = self.motionData.mean;
                case "max"
                    m = self.motionData.max;
                case "min"
                    m = self.motionData.min;
                case "sum"
                    m = self.motionData.activePixelCount;
                case "std"
                    m = self.motionData.std;
                case "var"
                    m = self.motionData.var;
            end
            m = m';
        end
    end
    
    methods
        function updateConcentration(self, iR, c)
            wellIdx = [self.infos(iR).wellIndex];
            for i = 1:numel(wellIdx)
                well = self.wells(wellIdx);
            	well.concentration = c;
                self.project.wellCollection.update(well);
            end
            self.updateResults();
        end
        
        function readLayoutFile(self, layoutFile)
            self.project.wellCollection.readLayoutFile(layoutFile);
            self.updateResults();
        end
        
        function updateValidState(self, embryoResultIndex, valid)
            info = self.infos(embryoResultIndex);
            w = self.project.wellCollection.wells(info.wellIndex);
            embryo = w.embryos(info.embryoIndex);
            embryo.valid = valid;
            w = w.replaceEmbryo(info.embryoIndex, embryo);
            self.project.wellCollection.update(w);
            self.updateResults();
        end

         function [s, iW] = collectEmbryos(self, embryoResultIndices)
             s = cell(1,numel(self.wells));
             info = self.infos(embryoResultIndices);
             iW = [info.wellIndex];
             iE = [info.embryoIndex];
             for i = 1:numel(iW)
                 s{iW(i)} = [s{iW(i)}, iE(i)];
             end
             iW = unique(iW);
         end
    end
    
    methods (Access = private)
        
        function updateResults(self)
            % Create embryo user data
            w = self.project.wellCollection.wells([self.infos.wellIndex]);
            embryoIndices = [self.infos.embryoIndex];
            % Process motion data
            self.embryoResult = EmbryoMotionResult(self.time, self.motion, w, embryoIndices, self.processor);
            self.meanResult = ProcessedMotionResult(self.embryoResult.time, mean(self.embryoResult.motion, 1), self.processor);
            self.concentrationResult = ConcentrationGroupMotionResult(self.embryoResult, self.processor);
            self.wellResult = WellGroupMotionResult(self.embryoResult, self.processor);
        end
    end
end